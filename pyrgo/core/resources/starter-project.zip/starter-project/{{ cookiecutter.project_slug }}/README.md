# "{{ cookiecutter.project_slug.lower().replace("-", "_") }}"
